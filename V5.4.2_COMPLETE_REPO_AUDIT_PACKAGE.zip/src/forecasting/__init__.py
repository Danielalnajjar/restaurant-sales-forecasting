"""Sales forecasting system for restaurant operations."""

__version__ = "0.1.0"
